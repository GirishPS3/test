let Singleton=(()=>{
    let instance;
    function createInstance(){
        let obj = new Object('Instance');
        return obj;
    }
    return {
        getInstance: ()=>{
            if(!instance){
                instance=createInstance();
            }
            return instance;
        }
    }
})()

let a = Singleton.getInstance();
let b = Singleton.getInstance();
console.log(a==b);
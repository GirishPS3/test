// “A constructor is a special method used to initialize a newly created object once the memory has been allocated for it. In JavaScript, as almost everything is an object, we’re most often interested in object constructors.”

function Person(name,age){
    this.name= name;
    this.age=age;
    this.getDetails = ()=>{
        console.log('fun')
        console.log(this.name,this.age);
    }
}
class Person1{
    constructor(name,age) {
        this.name= name;
        this.age=age;
        this.getDetails = ()=>{
            console.log('class')
            console.log(this.name,this.age);
        }
    }
}
let person1=new Person1('a',21);
person1.getDetails();

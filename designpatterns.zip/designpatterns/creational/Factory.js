function factory(){
    this.createShape=function(shapeType){
        let shape;
        switch(shapeType){
            case 'rectangle':
                shape=new Rectangle();
                break;
            case 'square':
                shape=new Square();
                break;
            case 'circle':
                shape=new Circle();
                break;

        }
        return shape
    }
}
var Rectangle = function () {
    this.draw = function () {
        console.log('This is a Rectangle');
    }
};
 
var Square = function () {
    this.draw = function () {
        console.log('This is a Square');
    }
};
 
var Circle= function () {
    this.draw = function () {
        console.log('This is a Circle');
    }
};
// let shape= new factory().createShape('rectangle');
//  shape= new factory().createShape('square');
let shape= new factory().createShape('circle');
shape.draw();
import React, { useState, useContext } from 'react';
import { Form, Button } from 'semantic-ui-react';
import { useMutation } from '@apollo/react-hooks';
import gql from 'graphql-tag';
import { AuthContext } from '../context/auth';
import { useForm } from '../util/hook';

export default function Login(props) {
    const context = useContext(AuthContext)
    const [errors, setErrors] = useState({});

    const { onChange, onSubmit, values } = useForm(LoginUser, {
        username: '',
        password: '',
    });
    const [addUser, { loading }] = useMutation(LOGIN_USER, {
        update(proxy, { data: { login: userData } }) {
            context.login(userData)
            props.history.push('/');
        },
        onError(err) {
            console.log(err)
            setErrors(err.graphQLErrors[0].extensions.exception.errors);
        },
        variables: values
    });
    function LoginUser() {
        addUser()
    }
    return (
        <div>
            <Form onSubmit={onSubmit} noValidate className={loading ? "loading" : ''}>
                <h1>Login</h1>
                <Form.Input label="userName"
                    placholder="userName..."
                    name="userName"
                    value={values.userName}
                    type="text"
                    onChange={onChange}
                />

                <Form.Input label="Password"
                    placholder="password..."
                    name="password"
                    value={values.password}
                    type="password"
                    onChange={onChange}
                />

                <Button type="submit" primary >Login</Button>
            </Form>
            {Object.keys(errors).length > 0 && (
                <div className="ui error message">
                    <ul className="list">
                        {Object.values(errors).map(value => (
                            <li key={value}>{value} </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    )
}

const LOGIN_USER = gql`
    mutation login(
        $userName: String!
        $password: String!
    ){
        login(
                userName: $userName
                password: $password
        ){
            id email userName createdAt token
        }
    }
`
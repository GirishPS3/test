import React, { useState } from 'react';
import { Form, Button } from 'semantic-ui-react';
import { useMutation } from '@apollo/react-hooks';
import gql from 'graphql-tag';

export default function Register(props) {
    const [errors, setErrors] = useState({});
    const [values, setValues] = useState({
        username: '',
        email: '',
        password: '',
        confirmPassword: ''
    });
    const onChange = (event) => {
        setValues({ ...values, [event.target.name]: event.target.value })
    }

    const [addUser, { loading }] = useMutation(REG_USER, {
        update(proxy, result) {
            props.history.push('/');
            console.log(result)
        },
        onError(err) {
            console.log(err)
            setErrors(err.graphQLErrors[0].extensions.exception.errors);
        },
        variables: values
    })
    const onSubmit = (e) => {
        e.preventDefault();
        addUser();
    };
    return (
        <div>
            <Form onSubmit={onSubmit} noValidate className={loading ? "loading" : ''}>
                <h1>Register</h1>
                <Form.Input label="userName"
                    placholder="userName..."
                    name="userName"
                    value={values.userName}
                    type="text"
                    onChange={onChange}
                />
                <Form.Input label="Email"
                    placholder="email..."
                    name="email"
                    type="text"
                    value={values.email}
                    onChange={onChange}
                />
                <Form.Input label="Password"
                    placholder="password..."
                    name="password"
                    value={values.password}
                    type="password"
                    onChange={onChange}
                />
                <Form.Input label="Confirm Password"
                    placholder="confirm password..."
                    name="confirmPassword"
                    type="password"
                    value={values.confirmPassword}
                    onChange={onChange}
                />
                <Button type="submit" primary >Register</Button>
            </Form>
            {Object.keys(errors).length > 0 && (
                <div className="ui error message">
                    <ul className="list">
                        {Object.values(errors).map(value => (
                            <li key={value}>{value} </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    )
}

const REG_USER = gql`
    mutation register(
        $userName: String!
        $email: String!
        $password: String!
        $confirmPassword: String!
    ){
        register(
            registerInput: {
                userName: $userName
                email: $email
                password: $password
                confirmPassword: $confirmPassword
            }
        ){
            id email userName createdAt token
        }
    }
`
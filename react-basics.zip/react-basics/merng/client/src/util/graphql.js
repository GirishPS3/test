import gql from 'graphql-tag';

export const GET_POSTS = gql`
query getPosts{
    getPosts{
        id body createdAt userName likeCount
        likes{
            userName
        }
        commentCount
        comments{
            id userName createdAt body
        }
    }
}`;
export const CREATE_POST_MUTATION = gql`
mutation createPost($body: String!){
    createPost(body: $body){
        id body createdAt userName
        likes{
            id userName createdAt
        }
        comments{
            id body userName createdAt
        }
        commentCount
    }
}
`
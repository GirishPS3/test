const bcryptjs = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { UserInputError } = require('apollo-server')
const User = require('../../models/User');
const { secretKey } = require('../../config');
const { validateRegisterInput, validateLoginInputs } = require('../../util/validators');

function generateToken(user) {
    return jwt.sign({
        id: user.id,
        email: user.email,
        userName: user.userName
    }, secretKey, { expiresIn: '1h' });
}
module.exports = {
    Mutation: {
        async login(_, { userName, password }) {
            const { valid, errors } = validateLoginInputs(userName, password);
            const user = await User.findOne({ userName });
            if (!valid) {
                throw new UserInputError('Errors', { errors });
            }
            if (!user) {
                errors.general = 'user not found';
                throw new UserInputError('user not found', { errors });
            }
            const match = await bcryptjs.compare(password, user.password);
            if (!match) {
                errors.general = 'wrong credentials';
                throw new UserInputError('wrong credentials', { errors });
            }
            const token = await generateToken(user);
            return {
                ...user._doc,
                id: user.id,
                token: token
            }

        },
        async register(_, { registerInput: { userName, password, confirmPassword, email } }, context, info) {
            //TODO make sure use doesn't already exist
            const { valid, errors } = validateRegisterInput(userName, password, confirmPassword, email);
            if (!valid) {
                throw new UserInputError('Errors', { errors });
            }
            const user = await User.findOne({ userName });
            if (user) {
                throw new UserInputError('user is taken', {
                    errors: {
                        userName: 'username already taken'
                    }
                })
            }
            password = await bcryptjs.hash(password, 12);
            const newUser = new User({
                email,
                userName,
                password,
                createdAt: new Date().toISOString()

            });
            const res = await newUser.save();
            const token = generateToken(res);
            return {
                ...res._doc,
                id: res.id,
                token: token
            }
        }
    }
}
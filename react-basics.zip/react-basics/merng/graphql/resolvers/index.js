const postResolvers = require('./post');
const userResolvers = require('./user');
const commentsResolvers = require('./comments');

module.exports = {
    Post: {
        commentCount: (parent) => parent.comments.length,
        likeCount: (parent) => parent.likes.length
    },
    Query: {
        ...postResolvers.Query,
    },
    Mutation: {
        ...userResolvers.Mutation,
        ...postResolvers.Mutation,
        ...commentsResolvers.Mutation
    },
    Subscription: {
        ...postResolvers.Subscription
    }
}
const { AuthenticationError } = require('apollo-server');
const jwt = require('jsonwebtoken');
const { secretKey } = require('../config')

module.exports = (context) => {
    //context = {...headers}
    const authHeader = context.req.headers.authorization;
    if (authHeader) {
        //Bearer .....
        const token = authHeader.split('Bearer ')[1];
        if (token) {
            try {
                const user = jwt.verify(token, secretKey);
                return user;
            }
            catch (err) {
                throw new AuthenticationError('Invalid token ')
            }
        }
        throw new Error('Authenticate token must be there bearer')
    }
    throw new Error('Authenticate token must be there')

}
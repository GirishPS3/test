module.exports = {
    MONGODB: 'mongodb+srv://girish312:girish312@cluster0.yuwz2.mongodb.net/Merng?retryWrites=true&w=majority',
    secretKey: 'someSecrete'
}
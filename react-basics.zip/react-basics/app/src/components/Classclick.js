import React, { Component } from 'react'

export class Classclick extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             name:'hello'
        }
        // 3rd(recommendd) approach this.clickHandler.bind(this);
    }
    //arrow functions 4th approach
    clickHandler=()=>{
        this.setState({name: 'world'})
    }
    render() {
        return (
            <div>
                {this.state.name}
                {/* 1st approch <button onClick={this.clickHandler.bind(this)}>Click</button> */}
                {/* 2nd approach <button onClick={()=>this.clickHandler()}>Click</button> */}
                <button onClick={this.clickHandler}>Click</button>
            </div>
        )
    }
}

export default Classclick

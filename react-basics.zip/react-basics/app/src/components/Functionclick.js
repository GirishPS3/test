import React from 'react'

function ReactEvents() {
    function clickHandler(){
        console.log('clicked')
    }
    return (
        <div>
            <button onClick={clickHandler}>CLick</button>
        </div>
    )
}

export default ReactEvents

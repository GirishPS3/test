import React from 'react';
import './App.css';
import Count from './components/Count';
import Functionclick from './components/Functionclick';
import ClassClick from './components/Classclick';



function App() {
  return (
    <div className="App">
      {/* <Count/> */}
      {/* <Functionclick/> */}
      <ClassClick/>
    </div>
  );
}

export default App;

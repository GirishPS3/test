function sayHi() {
    console.log("Hello " + arguments[0] + ", " + arguments[1]);
}

function howManyArgs() {
    console.log(arguments.length);
}

howManyArgs("string", 45); // 2
howManyArgs(); // 0
howManyArgs(12); // 1


//    Another interesting behavior of arguments is that its values always stay in sync with the values of the
// corresponding named parameters. For example:
function doAdd(num1, num2) {
    arguments[1] = 10;
    console.log(arguments[0] + num2);
}
doAdd(10, 20);//20


// When a function is defined using the arrow notation, the arguments passed to the function cannot
// be accessed using the arguments keyword; they can only be accessed using their named token in the
// function definition.
function foo() {
    console.log(arguments[0]);
}
foo(5); // 5
let bar = () => {
    console.log(arguments[0]);
};
bar(5); // ReferenceError: arguments is not defined

// NOTE All arguments in ECMAScript are passed by value. It is not possible to
// pass arguments by reference. If an object is passed as an argument, the value is
// just a reference to the object.

// Parameters also exist inside their own scope, and therefore cannot reference the scope of the function
// body. This would throw an error:
// Error
function makeKing(name = 'Henry', numerals = defaultNumeral) {
    let defaultNumeral = 'VIII';
    return `King ${name} ${numerals}`;
}

let values = [1, 2, 3, 4];
function getSum() {
    let sum = 0;
    for (let i = 0; i < arguments.length; ++i) {
        sum += arguments[i];
    }
    return sum;
}

// With the spread operator, you can unpack the outer array into individual arguments directly inside
// the function invocation:
console.log(getSum(...values)); // 10
// Because the size of the array is known, there are no restrictions on other parameters appearing before
// or after the spread operator, including other spread operators:
console.log(getSum(-1, ...values)); // 9
console.log(getSum(...values, 5)); // 15
console.log(getSum(-1, ...values, 5)); // 14
console.log(getSum(...values, ...[5, 6, 7])); // 28

//rest parameter
function getSum(...values) {
    // Sequentially sum all elements in 'values'
    // Initial total = 0
    return values.reduce((x, y) => x + y, 0);
}
console.log(getSum(1, 2, 3)); // 6

function factorial(num) {
    if (num <= 1) {
        return 1;
    } else {
        return num * arguments.callee(num - 1);
    }
}

//this
// which behaves differently when used inside a standard function and an arrow function.

// Inside a standard function, it is a reference to the context object that the function is operating on—
// often called the this value (when a function is called in the global scope of a web page, the this
// object points to window).


// Inside an arrow function, this references the context in which the arrow function expression is
// defined. This is demonstrated in the following example, where two different invocations of sayColor
// both reference the property of the window object, which is the context inside which the arrow function was initially defined:
window.color = 'red';
let o = {
    color: 'blue'
};

let sayColor = () => console.log(this.color);

sayColor(); // 'red'

o.sayColor = sayColor;
o.sayColor(); // 'red'


// . If a function is called normally, new.target will
// be undefined. If a function is called using the new keyword, new.target will reference the constructor or function.
function King() {
    if (!new.target) {
        throw 'King must be instantiated using "new"'
    }
    console.log('King instantiated using "new"');
}
new King(); // King instantiated using "new"
King(); // Error: King must be instantiated using "new"

//Each function has two properties: length and prototype. The length property indicates the number of named arguments that the function expects, as in this example:
function sayName(name) {
    console.log(name);
}

function sum(num1, num2) {
    return num1 + num2;
}

function sayHi() {
    console.log("hi");
}

console.log(sayName.length); // 1
console.log(sum.length); // 2
console.log(sayHi.length); // 0


//. The prototype is the actual location of all instance methods for reference types, meaning methods such as toString() and valueOf() actually exist on the prototype and are then accessed from the
//object instances. This property is very important in terms of defining your own reference types and inheritance.

//There are two additional methods for functions: apply() and call(). These methods both call the
// function with a specific this value, effectively setting the value of the this object inside the function body. The apply() method accepts two arguments: the value of this inside the function and an
// array of arguments. This second argument may be an instance of Array, but it can also be the
// arguments object. 
function sum(num1, num2) {
    return num1 + num2;
}

function callSum1(num1, num2) {
    return sum.apply(this, arguments); // passing in arguments object
}

function callSum2(num1, num2) {
    return sum.apply(this, [num1, num2]); // passing in array
}

console.log(callSum1(10, 10)); // 20
console.log(callSum2(10, 10)); // 20

//The call() method exhibits the same behavior as apply(), but arguments are passed to it differently. The first argument is the this value, but the remaining arguments are passed directly into the
// function. Using call() arguments must be enumerated specificall
function sum(num1, num2) {
    return num1 + num2;
}

function callSum(num1, num2) {
    return sum.call(this, num1, num2);
}

console.log(callSum(10, 10)); // 20



//    The true power of apply() and call() lies not in their ability to pass arguments but rather in their
// ability to augment the this value inside of the function. Consider the following example:
window.color = 'red';
let o = {
    color: 'blue'
};

function sayColor() {
    console.log(this.color);
}

sayColor(); // red

sayColor.call(this); // red
sayColor.call(window); // red
sayColor.call(o); // blue

//The advantage of using call() (or apply()) to augment the scope is that the object doesn’t need to
// know anything about the method.



//  The bind() method creates a new function instance whose this value is bound to the value that was passed into bind(). For example:
window.color = 'red';
var o = {
    color: 'blue'
};

function sayColor() {
    console.log(this.color);
}
let objectSayColor = sayColor.bind(o);
objectSayColor(); // blue

//Here, a new function called objectSayColor() is created from sayColor() by calling bind() and
// passing in the object o. The objectSayColor() function has a this value equivalent to o, so calling
// the function, even as a global call, results in the string "blue" being displayed

function factorial(num) {
    if (num <= 1) {
        return 1;
    } else {
        return num * factorial(num - 1);
    }
}
//    This is the classic recursive factorial function. Although this works initially, it’s possible to prevent it
//    from functioning by running the following code immediately after it:
let anotherFactorial = factorial;
factorial = null;
console.log(anotherFactorial(4)); // error!

// It’s advisable to always use arguments.callee of the function name whenever you’re writing recursive functions.
//The value of arguments.callee is not accessible to a script running in strict mode and will cause an error when attempts are made to read it

function outerFunction() {
    return innerFunction(); // tail call
}
//    With the ES6 optimization, executing this example would have the following effect in memory:
// 1. Execution reaches outerFunction body, first stack frame is pushed onto stack.
// 2. Body of outerFunction executes, return statement is reached. To evaluate the return statement, innerFunction must be evaluated.
// 3. Engine recognizes that first stack frame can safely be popped off the stack since the return
// value of innerFunction is also the return value of outerFunction.
// 4. outerFunction stack frame is popped off the stack.
// 5. Execution reaches innerFunction body, stack frame is pushed onto stack.
// 6. Body of innerFunction executes, and its returned value is evaluated.
// 7. innerFunction stack frame is popped off the stack

// The following are a few examples that violate these conditions and therefore are not subject to the
// tail call optimization:
"use strict";
// No optimization: tail call is not returned
function outerFunction() {
    innerFunction();
}
// No optimization: tail call is not directly returned
function outerFunction() {
    let innerFunctionResult = innerFunction();
    return innerFunctionResult;
}
// No optimization: tail call must be cast as a string after return
function outerFunction() {
    return innerFunction().toString();
}
// No optimization: tail call is a closure
function outerFunction() {
    let foo = 'bar';
    function innerFunction() { return foo; }
    return innerFunction();
}


// . Closures
// are functions that have access to variables from another function’s scope.

window.identity = 'The Window';

let object = {
    identity: 'My Object',
    getIdentityFunc() {
        return function () {
            return this.identity;
        };
    }
};

console.log(object.getIdentityFunc()()); // 'The Window'



//iife
// IIFE
(function () {
    for (var i = 0; i < count; i++) {
        console.log(i);
    }
})();

console.log(i); // Throws an error



//     for loop using a block scoped variable keyword—here, let—for the iterator will create a separate counter instance
//    per iteration, thereby allowing each click handler to reference that specific counter when executing.

// Strictly speaking, JavaScript has no concept of private members; all object properties are public.
// There is, however, a concept of private variables. Any variable defined inside a function or block is
// considered private because it is inaccessible outside that function. This includes function arguments,
// local variables, and functions defined inside other functions. Consider the following:
function add(num1, num2) {
    let sum = num1 + num2;
    return sum;
}

// The privileged method, being a closure, always holds a reference to the containing scope. Consider the following:
(function () {
    let name = '';

    Person = function (value) {
        name = value;
    };

    Person.prototype.getName = function () {
        return name;
    };

    Person.prototype.setName = function (value) {
        name = value;
    };
})();

let person1 = new Person('Nicholas');
console.log(person1.getName()); // 'Nicholas'
person1.setName('Matt');
console.log(person1.getName()); // 'Matt'

let person2 = new Person('Michael');
console.log(person1.getName()); // 'Michael'
console.log(person2.getName()); // 'Michael'


let singleton = {
    name: value,
    method() {
        // method code here
    }
};
//    The module pattern augments the basic singleton to allow for private variables and privileged methods, taking the following format:
let singleton = function () {
    // private variables and functions
    let privateVariable = 10;

    function privateFunction() {
        return false;
    }

    // privileged/public methods and properties
    return {
        publicProperty: true,

        publicMethod() {
            privateVariable++;
            return privateFunction();
        }
    };
}();
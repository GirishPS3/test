let person = {};
Object.defineProperty(person, "name", {
    writable: false,
    value: "Nicholas"
});
console.log(person.name); // "Nicholas"
person.name = "Greg";
// console.log(person.name); // "Nicholas"
// This example creates a property called name with a value of "Nicholas" that is read-only. The value of
// this property can’t be changed, and any attempts to assign a new value are ignored in nonstrict mode. In
// strict mode, an error is thrown when an attempt is made to change the value of a read-only property


//Object.assign
dest = {};
src = { id: 'src' };
result = Object.assign(dest, src);

result = Object.assign(dest, { a: 'foo' }, { b: 'bar' });
console.log(dest); // { a: foo, b: bar }
console.log(result); // { a: foo, b: bar }

dest = { id: 'dest' };
result = Object.assign(dest, { id: 'src1', a: 'foo' }, { id: 'src2', b: 'bar' });
// Object.assign will overwrite duplicate properties.
console.log(result); // { id: src2, a: foo, b: bar }
//If an error is thrown during the assignment, it will discontinue and exit with the thrown error.
// Object.assign() has no concept of “rolling back” earlier assignments so it is a best-effort method
// that may only partially complete.

// Object.is(), which behaves mostly as === does but also accounts for the corner cases listed previously. The method accepts exactly two
// arguments:
console.log(Object.is(true, 1)); // false
console.log(Object.is({}, {})); // false
console.log(Object.is("2", 2)); // false
// Correct 0, -0, +0 equivalence/nonequivalence:
console.log(Object.is(+0, -0)); // false
console.log(Object.is(+0, 0)); // true
console.log(Object.is(-0, 0)); // false

// Computed Property Keys
const nameKey = 'name';
const ageKey = 'age';
const jobKey = 'job';
let person = {
    [nameKey]: 'Matt',
    [ageKey]: 27,
    [jobKey]: 'Software engineer'
};

// Concise Method Syntax
person = {
    sayName(name) {
        console.log('My name is ${name}');
    }
};
person.sayName('Matt'); // My name is Matt

//    Shorthand method syntax and computed property keys are mutually compatible:
const methodKey = 'sayName';
person = {
    [methodKey](name) {
        console.log('My name is ${name}');
    }
}
person.sayName('Matt'); // My name is Matt


//destructing

person = {
    name: 'Matt',
    age: 27
};
let { name: personName, age: personAge } = person;

//    It is also possible to define default values, which will be applied in the event that a property does not
// exist in the source object:
let person = {
    name1: 'Matt',
    age: 27
};
let { name1, job = 'Software engineer' } = person;
console.log(name1); // Matt
console.log(job); // Software engineer

let { length } = 'foobar';
console.log(length); // 6
let { constructor: c } = 4;
console.log(c === Number); // true


let personName, personAge;
person = {
    name: 'Matt',
    age: 27
};
let { name: personName, age: personAge } = person;
console.log(personName, personAge); // Matt, 27




// Factort pattern
function Person(name, age, job) {
    this.name = name;
    this.age = age;
    this.job = job;
    this.sayName = function () {
        console.log(this.name);
    };
}

let person1 = new Person("Nicholas", 29, "Software Engineer");
let person2 = new Person("Greg", 27, "Doctor");
person1.sayName(); // Nicholas
person2.sayName(); // Greg

let person1 = new Person();
let person2 = new Person;


// problems with prototype
function Person() { }

Person.prototype = {
    constructor: Person,
    name: "Nicholas",
    age: 29,
    job: "Software Engineer",
    friends: ["Shelby", "Court"],
    sayName() {
        console.log(this.name);
    }
};

let person1 = new Person();
let person2 = new Person();

person1.friends.push("Van");

console.log(person1.friends); // "Shelby,Court,Van"
console.log(person2.friends); // "Shelby,Court,Van"
console.log(person1.friends === person2.friends); // true


//inheritance
// Implementing prototype chaining involves the following code pattern:
function SuperType() {
    this.property = true;
}

SuperType.prototype.getSuperValue = function () {
    return this.property;
};

function SubType() {
    this.subproperty = false;
}

// inherit from SuperType
SubType.prototype = new SuperType();

SubType.prototype.getSubValue = function () {
    return this.subproperty;
};

let instance = new SubType();
console.log(instance.getSuperValue()); // true


// classical inheritance
function SuperType() {
    this.colors = ["red", "blue", "green"];
}

function SubType() {
    // inherit from SuperType
    SuperType.call(this);
}

let instance1 = new SubType();
instance1.colors.push("black");
console.log(instance1.colors); // "red,blue,green,black"

let instance2 = new SubType();
console.log(instance2.colors); // "red,blue,green"




// CLASSES
class Person { }
// class expression
const Animal = class { };
// Like function expressions, class expressions cannot be referenced until they are evaluated in execution. However, an important departure from the parallel behavior of function definition is that, while
// function declarations are hoisted, class declarations are not

console.log(FunctionExpression); // undefined
var FunctionExpression = function () { };
console.log(FunctionExpression); // function() {}
console.log(FunctionDeclaration); // FunctionDeclaration() {}
function FunctionDeclaration() { }
console.log(FunctionDeclaration); // FunctionDeclaration() {}
console.log(ClassExpression); // undefined
var ClassExpression = class { };
console.log(ClassExpression); // class {}
console.log(ClassDeclaration); // ReferenceError: ClassDeclaration is not defined
class ClassDeclaration { }
console.log(ClassDeclaration); // class ClassDeclaration {}



//Each instance is assigned unique member objects, meaning nothing is shared on the prototype:



// super can only be used in a derived class constructor or static method.
class Vehicle {
    constructor() {
        super();
        // SyntaxError: 'super' keyword unexpected
    }
}
// ➤ The super keyword cannot be referenced by itself; it must be either invoked as a constructor
// or used to reference a static method.
class Vehicle { }
class Bus extends Vehicle {
    constructor() {
        //  console.log(super);
        // SyntaxError: 'super' keyword unexpected here
    }
}
// ➤ Calling super() will invoke the parent class constructor and assign the resulting
// instance to this.
class Vehicle { }
class Bus extends Vehicle {
    constructor() {
        super();
        console.log(this instanceof Vehicle);
    }
}



//Date Type
let now = new Date(); //current date and time
let someDate = new Date(Date.parse("May 23, 2019")); //specific date and time , 
//different formats
// ➤month/date/year (such as 5/23/2019)
// ➤month_name date, year (such as May 23, 2019)
// ➤ day_of_week month_name date year hours:minutes:seconds time_zone (such as Tue May 23
// 2019 00:00:00 GMT-0700)
// ➤ ISO 8601 extended format YYYY-MM-DDTHH:mm:ss.sssZ (such as 2019-05-
// 23T00:00:00). This works only in ECMAScript 5–compliant implementations.

// . The Date constructor will call Date.parse() behind the scenes if a string is passed in directly, meaning that the
// following code is identical to the previous example:
someDate = new Date("May 23, 2019");

// The arguments for Date.UTC() are the year, the zero-based month (January is 0, February is 1, and so on), the day of the month (1 through 31),
// and the hours (0 through 23), minutes, seconds, and milliseconds of the time. Of these arguments,
// only the first two (year and month) are required.
someDate = new Date(Date.UTC(2000, 4))  //Mon May 01 2000 05:30:00 GMT+0530 (India Standard Time)

// new Date().toLocaleString()
// "1/17/2021, 5:05:13 PM"
// new Date().toLocaleDateString()
// "1/17/2021"
// new Date().toLocaleTimeString()
// "5:05:32 PM"


/*Regex Type*/
// ➤ g—"Indicates global mode", meaning the pattern will be applied to all of the string instead of
// stopping after the first match is found.
// ➤ i—"Indicates case-insensitive mode", meaning the case of the pattern and the string are
// ignored when determining matches.
// ➤ m—"Indicates multiline mode", meaning the pattern will continue looking for matches after
// reaching the end of one line of text.
// ➤ y—Indicates sticky mode, meaning the pattern will only look at the string contents
// beginning at lastIndex.
// ➤ u—Indicates Unicode mode is enabled.

// all metacharacters must be escaped when used as part of the pattern.The metacharacters are as follows:
// ( [ { \ ^ $ | ) ] } ? * + .
// Match all instances of "at" in a string.
let pattern1 = /at/g;

// Match the first instance of "bat" or "cat", regardless of case.
let pattern2 = /[bc]at/i;

// Match all three-character combinations ending with "at", regardless of case.
let pattern3 = /.at/gi;

let text = "cat, bat, sat, fat";
let pattern = /.at/;
//exec()
let matches = pattern.exec(text);
console.log(matches.index); // 0
console.log(matches[0]); // cat
console.log(pattern.lastIndex); // 0

// With the global g flag set on the pattern, each call to exec() moves further into the string looking for matches

//test()
text = "000-00-0000";
pattern = /\d{3}-\d{2}-\d{4}/;
pattern.test(text) //true
//$-at end
//^-at the begining
//(? aa) follwed by a
//d{4} 4digits
///\W/g non words
// /\w/g words
// /\s/ white space
// /h.t/ any one character between h and t
// /h.*t/ many characters in between
//[a-b] all small alphabets
//[^a-z] other than small alphabets

let message = "ab☺de";
console.log(message.charAt(1)); // b
console.log(message.charAt(2)); // <?>
console.log(message.charAt(3)); // <?>
console.log(message.charAt(4)); // d
console.log(message.charCodeAt(1)); // 98
console.log(message.charCodeAt(2)); // 55357
console.log(message.charCodeAt(3)); // 56842
console.log(message.charCodeAt(4)); // 100
console.log(String.fromCharCode(0x1F60A)); // ☺
console.log(String.fromCharCode(97, 98, 55357, 56842, 100, 101)); // ab☺de


//String
let stringValue = "hello world";
console.log(stringValue.slice(3)); // "lo world"
console.log(stringValue.substring(3)); // "lo world"
console.log(stringValue.substr(3)); // "lo world"
console.log(stringValue.slice(3, 7)); // "lo w"
console.log(stringValue.substring(3, 7)); // "lo w"
console.log(stringValue.substr(3, 7)); // "lo worl"

console.log(stringValue.slice(-3)); // "rld"
console.log(stringValue.substring(-3)); // "hello world"
console.log(stringValue.substr(-3)); // "rld"
console.log(stringValue.slice(3, -4)); // "lo w"
console.log(stringValue.substring(3, -4)); // "hel"
console.log(stringValue.substr(3, -4)); // "" (empty string)

//trim
stringValue = " hello world ";
let trimmedStringValue = stringValue.trim();
console.log(stringValue); // " hello world "
console.log(trimmedStringValue); // "hello world"
stringValue = "na ";
console.log(stringValue.repeat(16) + "batman");
// na na na na na na na na na na na na na na na na batman

//pad
stringValue = "foo";
console.log(stringValue.padStart(6)); // " foo"
console.log(stringValue.padStart(9, ".")); // "......foo"
console.log(stringValue.padEnd(6)); // "foo "
console.log(stringValue.padEnd(9, ".")); // "foo......"


// string iterator
let message = "abc";
let stringIterator = message[Symbol.iterator]();
console.log(stringIterator.next()); // {value: "a", done: false}
console.log(stringIterator.next()); // {value: "b", done: false}
console.log(stringIterator.next()); // {value: "c", done: false}
console.log(stringIterator.next()); // {value: undefined, done: true}

//destructing
message = "abcde";
console.log([...message]); // ["a", "b", "c", "d", "e"]

let text = "cat, bat, sat, fat";
let pattern = /.at/;

// same as pattern.exec(text)
let matches = text.match(pattern);
console.log(matches.index); // 0
console.log(matches[0]); // "cat"
console.log(pattern.lastIndex); // 0
// The array returned from match() is the same array that is returned when the RegExp object’s exec()
// method

stringValue = "yellow";
console.log(stringValue.localeCompare("brick")); // 1
console.log(stringValue.localeCompare("yellow")); // 0
console.log(stringValue.localeCompare("zoo")); // -1

// isNaN(), isFinite(), parseInt(), and parseFloat(), are actually
// methods of the Global object. In addition to these, there are several other methods available on the
// Global object.
// . The main difference between the two methods
// is that encodeURI() does not encode special characters that are part of a URI, such as the colon,
// forward slash, question mark, and pound sign, whereas encodeURIComponent() encodes every nonstandard character it finds. Consider this example:
let uri = "http:// www.wrox.com/illegal value.js#start";

// "http:// www.wrox.com/illegal%20value.js#start"
console.log(encodeURI(uri));


// eval  method works like an entire ECMAScript interpreter and accepts one argument, a string
// of ECMAScript (or JavaScript) to execute. Here’s an example:
eval("console.log('hi')");
// This line is functionally equivalent to the following:
console.log("hi");
//Use extreme caution with eval(), especially when passing
// user-entered data into it, as this method exposes a large attack surface for XSS
// exploits. A mischievous user could insert values that might compromise your site
// or "application security."

Math.floor(Math.random() * 10) //displays random number less than 10
let num = Math.floor(Math.random() * 10 + 1); // 1 to 10
let num = Math.floor(Math.random() * 9 + 2); // 2 to 10
// Math.floor(Math.random() * choices + lowerValue);


// "http%3A%2F%2Fwww.wrox.com%2Fillegal%20value.js%23start"
console.log(encodeURIComponent(uri));
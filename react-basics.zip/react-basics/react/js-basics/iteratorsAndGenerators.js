// An iterator is a single-use object that will iterate through whatever iterable it is associated with. The
// Iterator API uses a next()method to advance through the iterable. Each successive time next() is
// invoked, it will return an IteratorResult object containing the next value in the iterator. The current position the iterator is at cannot be known without invoking the next() method.

let arr = ['foo', 'bar'];
// Iterator
let iter = arr[Symbol.iterator]();
console.log(iter); // ArrayIterator {}
// Performing iteration
console.log(iter.next()); // { done: false, value: 'foo' }
console.log(iter.next()); // { done: false, value: 'bar' }
console.log(iter.next()); // { done: true, value: undefined }

//Generators
// offers the ability to pause and resume code execution inside a single function block. 

//Arrow functions cannot be used as generator functions.
// The function will be considered a generator irrespective of the whitespace surrounding the asterisk:
// Equivalent generator functions:
function* generatorFnA() { }
function* generatorFnB() { }
function* generatorFnC() { }

// generator functions produce a generator object. Generator objects begin in a state of
// suspended execution. Like iterators, these generator objects implement the Iterator interface and
// therefore feature a next() method, which, when invoked, instructs the generator to begin or resume
// execution

function* generatorFn() { }
let generatorObject = generatorFn();
console.log(generatorObject); // generatorFn {<suspended>}
console.log(generatorObject.next()); // { done: true, value: undefined } 

// The yield keyword allows generators to stop and start execution, and it is what makes generators
// truly useful. Generator functions will proceed with normal execution until they encounter a yield
// keyword. Upon encountering the keyword, execution will be halted and the scope state of the function will be preserved. Execution will only resume when the next() method is invoked on the generator object:

function* generatorFn() {
    yield;
}
let generatorObject = generatorFn();
console.log(generatorObject.next()); // { done: false, value: undefined }
console.log(generatorObject.next()); // { done: true, value: undefined } 

function* generatorFn() {
    yield 'foo';
    yield 'bar';
    return 'baz';
}
let generatorObject = generatorFn();
console.log(generatorObject.next()); // { done: false, value: 'foo' }
console.log(generatorObject.next()); // { done: false, value: 'bar' }
console.log(generatorObject.next()); // { done: true, value: 'baz' } 


//    The yield keyword can only be used inside a generator function; anywhere else will throw an error.
// Like the function return keyword, the yield keyword must appear immediately inside a generator
// function definition. Nesting further inside a non-generator function will throw a syntax error:

// valid
function* validGeneratorFn() {
    yield;
}
// invalid
function* invalidGeneratorFnA() {
    function a() {
        yield;
    }
}
// invalid
function* invalidGeneratorFnB() {
    const b = () => {
        yield;
    }
}
// invalid
function* invalidGeneratorFnC() {
    (() => {
        yield;
    })();
}
// Using a Generator Object as an Iterable
function* generatorFn() {
    yield 1;
    yield 2;
    yield 3;
}
for (const x of generatorFn()) {
    console.log(x);
}

//    Like the generator function asterisk, whitespace around the yield asterisk will not alter its behavior:
function* generatorFn() {
    yield* [1, 2];
    yield* [3, 4];
    yield* [5, 6];

    for (const x of generatorFn()) {
        console.log(x);
    }
    // 1
    // 2
    // 3
    // 4
    // 5
    // 6 
}
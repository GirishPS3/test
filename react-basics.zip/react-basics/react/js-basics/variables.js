console.log(
    `
    var 
        -function scope(variable declared inside a function available inside but not outside)
        - avaiable in window object if its declared as a global variable;
        -variables are hosited (moved to top) to the function scope
        -function foo() {
            console.log(age);
            var age = 26;
        }
        //after hoisted
        -function foo() {
            var age;
            console.log(age);
            var age = 26;
        }
        foo(); //undefined
        “hoisting,” where the interpreter pulls all variable declarations to the top of its scope
    `
);
console.log(`
    let
        -block scope(like if, for, etc.. outside the block variable can't be acessed)
        -redundand redclarations not allowed in same scope
            let age;
            let age; // SyntaxError; identifier 'age' has already been declared
              - - -or
            var age = 10;
            let age = 20;// SyntaxError; identifier 'age' has already been declared
            ----
            let age;
            var age; // SyntaxError
            - - - but
            let age = 30;
            console.log(age); // 30
            if (true) {
                let age = 26;
                console.log(age); // 26
            }
        -All declarations (function, var, let, const and class) are hoisted in JavaScript, while the var declarations are initialized with undefined, but let and const declarations remain uninitialized.
        - The segment of execution that occurs before the declaration is referred to as the “temporal
        dead zone,” and any attempted references to these variables will throw a ReferenceError.(This means you can’t access the variable before the engine evaluates its value at the place it was declared in the source code. )
        -when using let to declare the loop iterator, behind the scenes the JavaScript engine will actually declare a new iterator variable each loop iteration. Each setTimeout references that separate
            instance, and therefore it will console.log the expected value: the value of the iterator variable
            when that loop iteration was executed.
            for (let i = 0; i < 5; ++i) {
            setTimeout(() => console.log(i), 0)
            }
            // console.logs 0   , 1, 2, 3, 4 
        -let as global variable will not be ataached to window object
            var name = 'Matt';
            console.log(window.name); // 'Matt'
            let age = 26;
            console.log(window.age); // undefined 
`)
// The typeof operator is called like this:
// let message = "some string";
// console.log(typeof message); // "string"
// console.log(typeof(message)); // "string"
// console.log(typeof 95); // "number"
// typeof null returns a value of "object"
console.log(`
data types-
    UNDEFINED
            -When a variable is
            declared using var or let but not initialized, it is assigned the value of undefined
            -Note that a variable containing the value of undefined is different from a variable that hasn’t been
            defined at all.
    Null 
            -The Null type is the second data type that has only one value: the special value null. Logically, a
            null value is an empty object pointer, which is why typeof returns "object" when it’s passed a
            null value 
            -The value undefined is a derivative of null
            -console.log(null == undefined); // true
    boolena
            -. These values are distinct from numeric values, so true is not equal to 1, and
            false is not equal to 0. 
            -DATA TYPE    VALUES CONVERTED TO TRUE VALUES       CONVERTED TO FALSE
            Boolean      true                                   false
            String       Any nonempty string                    "" (empty string)
            Number       Any nonzero number(including infinity)   0, NaN (See the “NaN” section later in
            this chapter.)
            Object       Any object                               null
            Undefined    n/a                                     undefined
    nan
            -console.log(isNaN(NaN)); // true
            console.log(isNaN(10)); // false - 10 is a number
            console.log(isNaN("10")); // false - can be converted to number 10
            console.log(isNaN("blue")); // true - cannot be converted to a number
            console.log(isNaN(true)); // false - can be converted to number 1
    Number() -
            -➤ When applied to Boolean values, true and false get converted into 1 and 0, respectively.
            ➤ When applied to numbers, the value is simply passed through and returned.
            ➤ When applied to null, Number() returns 0.
            ➤ When applied to undefined, Number() returns NaN.
            ➤ When applied to strings, the following rules are applied:
            ➤ If the string contains only numeric characters, optionally preceded by a plus or
            minus sign, it is always converted to a decimal number, so Number("1") becomes 1,
            Number("123") becomes 123, and Number("011") becomes 11 (note: leading zeros
            are ignored).
            ➤ If the string contains a valid floating-point format, such as "1.1", it is converted into
            the appropriate floating-point numeric value (once again, leading zeros are ignored).
            ➤ If the string contains a valid hexadecimal format, such as "0xf", it is converted into
            an integer that matches the hexadecimal value.
            ➤ If the string is empty (contains no characters), it is converted to 0.
            ➤ If the string contains anything other than these previous formats, it is converted into NaN.
            ➤ When applied to objects, the valueOf() method is called and the returned value is converted
            based on the previously described rules. If that conversion results in NaN, the toString()
            method is called and the rules for converting strings are applied.

            Number("+122") //122
            Number("+122aaaa'") //NaN
            parseInt("+122aaaa'") //122
            parseInt(true) //NaN
            Number(true) //1

            EXPRESSION VALUE
            null == undefined true
            "NaN" == NaN false
            5 == NaN false
            NaN == NaN false
            NaN != NaN true
            false == 0 true
            true == 1 true
            true == 2 false
            undefined == 0 false
            null == 0 false
            "5" == 5 true
`)
console.log(`
console.log(stringValue.slice(3)); // "lo world"
console.log(stringValue.substring(3)); // "lo world"
console.log(stringValue.substr(3)); // "lo world"
console.log(stringValue.slice(3, 7)); // "lo w"
console.log(stringValue.substring(3,7)); // "lo w"
console.log(stringValue.substr(3, 7)); // "lo worl"


let stringValue = "hello world";
console.log(stringValue.slice(-3)); // "rld"
console.log(stringValue.substring(-3)); // "hello world"
console.log(stringValue.substr(-3)); // "rld"
console.log(stringValue.slice(3, -4)); // "lo w"
console.log(stringValue.substring(3, -4)); // "hel"
console.log(stringValue.substr(3, -4)); // "" (empty string)

Manual use of the iterator works as follows:
let message = "abc";
let stringIterator = message[Symbol.iterator]();
console.log(stringIterator.next()); // {value: "a", done: false}
console.log(stringIterator.next()); // {value: "b", done: false}
console.log(stringIterator.next()); // {value: "c", done: false}
console.log(stringIterator.next()); // {value: undefined, done: true}

let message = "abcde";
console.log([...message]); // ["a", "b", "c", "d", "e"]
`)
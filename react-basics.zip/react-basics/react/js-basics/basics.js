console.log('first');
console.log(
    `A complete js is made up of 3 distinct parts
-the core(Ecma scirpt)
-DOM(document object model)
-BOM(browser object model)'`);

console.log('ECMA script- describes the core functionality> Syntax, types, statements, keywords, reserved words, operatores Global object   ');
console.log(' DOM - its an API maps out an entire page as a heirarchy of Nodes, used to manipulate node in page(remove , add, replace and modify the nodes)');
console.log(`The Document Object Model (DOM), which provides methods and interfaces for working
with the content of a web page`)
console.log(
    `DOM views - 
DOM-events-
DOM style-
DOM traversal and range`
)
console.log(
    `BOM- using this developers can interact with the browser outside of the context of its displayed page
    like-
        ➤ The capability to pop up new browser windows
        ➤ The capability to move, resize, and close browser windows
        ➤ The navigator object, which provides detailed information about the browser
        ➤ The location object, which gives detailed information about the page loaded in the browser
        ➤ The screen object, which gives detailed information about the user’s screen resolution
        ➤ The performance object, which gives detailed information about the browser’s memory
        consumption, navigational behavior, and timing statistics
        ➤ Support for cookies
        ➤ Custom objects such as XMLHttpRequest and Internet Explorer’s ActiveXObject
    `
);
console.log('way to  insert js to html- <script> tag');
console.log(
    `
    async  —Optional. Indicates that the script should begin downloading immediately
    but should not prevent other actions on the page such as downloading resources or
    waiting for other scripts to load.
    defer—Optional. Indicates that the execution of the script can safely be deferred until after
the document’s content has been completely parsed and displayed.
    `
);
console.log(`The JavaScript code contained inside a <script> element is interpreted from top to bottom. In the
case of this example, a function definition is interpreted and stored inside the interpreter environment. The rest of the page content is not loaded and/or displayed until after all of the code inside the
<script> element has been evaluated.`)
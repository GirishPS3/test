Array.from("Matt"); //["M", "a", "t", "t"]
const m = new Map().set(1, 2)
    .set(3, 4);
const s = new Set().add(1)
    .add(2)
    .add(3)
    .add(4);
console.log(Array.from(m)); // [[1, 2], [3, 4]]
console.log(Array.from(s)); // [1, 2, 3, 4] 
const a1 = [1, 2, 3, 4];
const a2 = Array.from(a1, x => x ** 2);
const a3 = Array.from(a1, function (x) { return x ** this.exponent }, { exponent: 2 });

// A unique characteristic of length is that it’s not read-only. By setting the length property, you can
// easily remove items from or add items to the end of the array. Consider this example:
let colors = ["red", "blue", "green"]; // creates an array with three strings
colors.length = 2;
console.log(colors[2]); // undefined

let colors1 = ["red", "blue", "green"]; // creates an array with three strings
colors1.length = 4;
console.log(colors1[3]); // undefined


const a = ["foo", "bar", "baz", "qux"];
// Because these methods return iterators, you can funnel their contents
// into array instances using Array.from()
const aKeys = Array.from(a.keys());
const aValues = Array.from(a.values());
const aEntries = Array.from(a.entries());
console.log(aKeys); // [0, 1, 2, 3]
console.log(aValues); // ["foo", "bar", "baz", "qux"]
console.log(aEntries); // [[0, "foo"], [1, "bar"], [2, "baz"], [3, "qux"]] 

for (const [idx, element] of a.entries()) {
    console.log(idx);
    console.log(element);
}


const zeroes = [0, 0, 0, 0, 0];
// Fill the entire array with 5
zeroes.fill(5);
console.log(zeroes); // [5, 5, 5, 5, 5]
zeroes.fill(0); // reset
// Fill all indices >=3 with 6
zeroes.fill(6, 3);
console.log(zeroes); // [0, 0, 0, 6, 6]
zeroes.fill(0); // reset
// Fill all indices >= 1 and < 3 with 7
zeroes.fill(7, 1, 3);
console.log(zeroes); // [0, 7, 7, 0, 0];
zeroes.fill(0); // reset
// Fill all indices >=1 and < 4 with 8
// (-4 + zeroes.length = 1)
// (-1 + zeroes.length = 4)
zeroes.fill(8, -4, -1);
console.log(zeroes); // [0, 8, 8, 8, 0];
// fill() silently ignores ranges that exceed the boundaries of the array, are zero length, or go
// backwards:

let ints = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
ints.copyWithin(5);
console.log(ints); // [0, 1, 2, 3, 4, 0, 1, 2, 3, 4]


// CONVERSION METHODS
colors = ["red", "blue", "green"];
alert(colors.toString()); // red,blue,green
alert(colors.valueOf()); // red,blue,green
alert(colors); // red,blue,green


// Map
// An empty Map is instantiated with the new keyword:
const m = new Map();
// If you wish to populate the Map when it is initialized, the constructor optionally accepts an iterable object, expecting it to contain key/value pair arrays. Each pair in the iterable argument will be
// inserted into the newly created Map in the order in which they are iterated:
// Initialize map with nested arrays
const m1 = new Map([
    ["key1", "val1"],
    ["key2", "val2"],
    ["key3", "val3"]
]);
alert(m1.size); // 3
// Initialize map with custom-defined iterator
const m2 = new Map({
    [Symbol.iterator]: function* () {
        yield ["key1", "val1"];
        yield ["key2", "val2"];
        yield ["key3", "val3"];
    }
});
console.log(m2.size())//3
m.set("firstName", "Matt")
    .set("lastName", "Frisbie");
alert(m.has("firstName")); // true
alert(m.get("firstName")); // Matt
alert(m.size); // 2
m.delete("firstName"); // deletes only this key/value pair
alert(m.has("firstName")); // false
alert(m.has("lastName")); // true
alert(m.size); // 1
m.clear(); // destroys all key/value pairs in this Map instance
alert(m.has("firstName")); // false
alert(m.has("lastName")); // false
alert(m.size);
// A Map instance can provide an Iterator that contains array pairs in the form of [key, value] in
// insertion order. This iterator can be retrieved using entries(), or the Symbol.iterator property,
// which references entries():
const m = new Map([
    ["key1", "val1"],
    ["key2", "val2"],
    ["key3", "val3"]
]);
alert(m.entries === m[Symbol.iterator]); // true
m.keys();
// m.values();
// /. Results may vary by browser, but given a fixed amount of memory, a Map will
// be able to store roughly 50 percent more key/value pairs than an Object.
//slightly faster insertion

//weak map
// The “weak” designation describes how JavaScript’s garbage collector treats keys in a WeakMap
// Keys in a WeakMap can only be of type or inherit from Object

const key1 = { id: 1 },
    key2 = { id: 2 },
    key3 = { id: 3 };
// Initialize WeakMap with nested arrays
const wm1 = new WeakMap([
    [key1, "val1"],
    [key2, "val2"],
    [key3, "val3"]
]);
alert(wm.get(key1)); // val2
alert(wm.get(key2)); // val2
alert(wm.get(key3)); // val3

// /set
const s1 = new Set(["val1", "val2", "val3"]);
s.add("Matt")
    .add("Frisbie");
alert(s.has("Matt")); // true
alert(s.size);
s.values();
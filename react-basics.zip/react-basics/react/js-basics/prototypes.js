function Test() { }

Test.prototype.name = 'test';
Test.prototype.name2 = 'test2';
Test.prototype.getName = () => {
    console.log(this.name);
}

let test = new Test();
let test1 = new Test();

test.name = 'testName';
console.log(test1.name);
console.log(test.name);
delete test1.name;
console.log(test.name)
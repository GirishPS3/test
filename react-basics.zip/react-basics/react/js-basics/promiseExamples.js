let p1 = new Promise((resolve, reject) => resolve());
setTimeout(console.log, 0, p1); // Promise <resolved>
// let p2 = new Promise((resolve, reject) => reject());
// setTimeout(console.log, 0, p2); // Promise <rejected>
// Uncaught error (in promise)

let p11 = new Promise((resolve, reject) => {
    resolve();
    reject(); // No effect
});
let p = new Promise((resolve, reject) => {
    setTimeout(reject, 10000); // After 10 seconds, invoke reject()
    // Do executor things
});
setTimeout(console.log, 0, p); // Promise <pending>
setTimeout(console.log, 11000, p); // Check state after 11 seconds

// Similar in concept to Promise.resolve(), Promise.reject() instantiates a rejected promise and
// throws an asynchronous error (which will not be caught by try/catch and can only be caught by a
// rejection handler). The following two promise instantiations are effectively equivalent:
p1 = new Promise((resolve, reject) => reject());
p2 = Promise.reject();



try {
    throw new Error('foo');
} catch (e) {
    console.log(e); // Error: foo
}
try {
    Promise.reject(new Error('bar'));
} catch (e) {
    console.log(e);
}
// Uncaught (in promise) Error: bar
//promises actually behave:
// They are synchronous objects—used inside a synchronous mode of execution—acting as a bridge to
// an asynchronous mode of execution.

// The ECMAScript Promise type implements the Thenable interface. This simplistic interface is not
// to be confused with other interfaces or type definitions in packages like TypeScript, which lay out a
// much more specific form of a Thenable interface.

// Returning a pending promise is an unusual case, as once the promise resolves, the new promise will
// still behave as a passthrough for the initial promise:
p1 = Promise.resolve('foo');
// The resolved value is ignored
p2 = p1.finally(
    () => new Promise((resolve, reject) => setTimeout(() => resolve('bar'), 100)));
setTimeout(console.log, 0, p2); // Promise <pending>
setTimeout(() => setTimeout(console.log, 0, p2), 200);
// After 200ms:
// Promise <resolved>: foo


let synchronousResolve;
// Create a promise and capture the resolve function in a local variable
let promise = new Promise((resolve) => {
    synchronousResolve = function () {
        console.log('1: invoking resolve()');
        resolve();
        console.log('2: resolve() returns');
    };
});
promise.then(() => console.log('4: then() handler executes'));
synchronousResolve();
console.log('3: synchronousResolve() returns');


// Resolved values and rejected reasons are assigned from inside the executor as the first argument to
// the resolve() or reject() functions. These values are provided to their respective onResolved or
// onRejected handler as the sole parameter. This handoff is demonstrated here:
p1 = new Promise((resolve, reject) => resolve('foo'));
p1.then((value) => console.log(value)); // foo
p2 = new Promise((resolve, reject) => reject('bar'));
p2.catch((reason) => console.log(reason)); // bar

// throw Error('foo');
// console.log('bar'); // This will never print
// Uncaught Error: foo

Promise.reject(Error('foo'));
console.log('bar');
// bar
// Uncaught (in promise) Error: foo

// As demonstrated earlier in this chapter with Promise.reject(), an asynchronous error can be
// caught only with an asynchronous onRejection handler.
// Correct
Promise.reject(Error('foo')).catch((e) => { });
// Incorrect
try {
    Promise.reject(Error('foo'));
} catch (e) { }


let A = new Promise((resolve, reject) => {
    console.log('A');
    resolve();
});
let B = A.then(() => console.log('B'));
let C = A.then(() => console.log('C'));
B.then(() => console.log('D'));
B.then(() => console.log('E'));
C.then(() => console.log('F'));
C.then(() => console.log('G'));



// Promise.all()
// The Promise.all() static method creates an all-or-nothing promise that resolves only once every
// promise in a collection of promises resolves. The static method accepts an iterable and returns a
// new promise:
let p1 = Promise.all([
    Promise.resolve(),
    Promise.resolve()
]);
// Elements in the iterable are coerced into a promise using Promise.resolve()
let p2 = Promise.all([3, 4]);
// Empty iterable is equivalent to Promise.resolve()
let p3 = Promise.all([]);
// Invalid syntax
let p4 = Promise.all();
// TypeError: cannot read Symbol.iterator of undefined

p = Promise.all([
    Promise.resolve(3),
    Promise.resolve(),
    Promise.resolve(4)
]);
p.then((values) => setTimeout(console.log, 0, values)); // [3, undefined, 4]

// The Promise.race() static method creates a promise that will mirror whichever promise inside a
// collection of promises reaches a resolved or rejected state first. 
let p1 = Promise.race([
    Promise.resolve(),
    Promise.resolve()
]);
// Elements in the iterable are coerced into a promise using Promise.resolve()
let p2 = Promise.race([3, 4]);
// Empty iterable is equivalent to new Promise(() => {})
let p3 = Promise.race([]);
// Invalid syntax
let p4 = Promise.race();
// TypeError: cannot read Symbol.iterator of undefined 

// Reject occurs first, resolve in timeout ignored
let p2 = Promise.race([
    Promise.reject(4),
    new Promise((resolve, reject) => setTimeout(resolve, 1000))
]);
setTimeout(console.log, 0, p2); // Promise <rejected>: 4
// Iterator order is the tiebreaker for settling order
let p3 = Promise.race([
    Promise.resolve(5),
    Promise.resolve(6),
    Promise.resolve(7)
]);
setTimeout(console.log, 0, p3); // Promise <resolved>: 5


// Serial Promise Composition
function addTwo(x) { return x + 2; }
function addThree(x) { return x + 3; }
function addFive(x) { return x + 5; }
function addTen(x) {
    return addFive(addTwo(addThree(x)));
}
console.log(addTen(7)); // 17

function addTen(x) {
    return Promise.resolve(x)
        .then(addTwo)
        .then(addThree)
        .then(addFive);
}
addTen(8).then(console.log); // 18


//ASYNC FUNCTIONS
// In an async function, whatever value is returned with the return keyword (or undefined if there is
//     no return) will be effectively converted into a promise object with Promise.resolve(). An async
//     function will always return a promise object. Outside the function, the evaluated function will be this
//     promise object:
async function foo() {
    console.log(1);
    return 3;
}
// Attach a resolved handler to the returned promise
foo().then(console.log);
console.log(2);

// Because an async function indicates to code invoking it that there is no expectation of timely completion, the logical extension of this behavior is the ability to pause and resume execution. This exact
// feature is possible using the await keyword, which is used to pause execution while waiting for a
// promise to resolve
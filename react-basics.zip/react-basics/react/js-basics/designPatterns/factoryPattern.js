function Developer(name) {
    this.name = name;
    this.type = 'Developer'
}
function Tester(name) {
    this.name = name;
    this.type = 'Tester'
}
function EmployeeFactory() {
    // this.create = (name, type) => {
    //     switch (type) {
    //         case 1:
    //             return new Developer(name)
    //             break;
    //         case 2:
    //             return new Tester(name)
    //             break;
    //     }
    // }
}
function say() {
    console.log(this.name + '  ' + this.type)
}

const employeeFactory = new EmployeeFactory()
console.log(employeeFactory)
const employees = [];

employees.push(employeeFactory.create('test', 1))
employees.push(employeeFactory.create('test1', 2))

employees.forEach(employee => {
    say.call(employee);
})

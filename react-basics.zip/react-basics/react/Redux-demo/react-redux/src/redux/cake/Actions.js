import { BUY_CAKE } from './ActionType';
export function buyCake() {
    return {
        type: BUY_CAKE
    }
}
import { createStore } from 'redux';
import reducer from './cake/Reducers';
const store = createStore(reducer);
export default store;
import React from 'react'
import { useSelector, useDispatch } from 'react-redux';
import { buyCake } from '../redux';


function CakeCounterHooks() {
    const numOfCakes = useSelector(state => state.numOfCakes);
    let dispatch = useDispatch();
    return (
        <div>
            <h2>Num of cakes {numOfCakes}</h2>
            <button onClick={() => dispatch(buyCake())}>Buy</button>
        </div>
    )
}

export default CakeCounterHooks

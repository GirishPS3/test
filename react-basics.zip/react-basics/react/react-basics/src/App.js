import React, { Component } from 'react'
import './index.css'
class App extends Component {
  constructor(props) {
    super(props)

    this.state = {
      count: 0
    }
  }
  static getDerivedStateFromProps(props, state) {
    console.log('getDerivedStateFromProps');
    return {
      count: 1
    }
  }

  componentDidMount() {
    console.log('componentDidMount')

  }
  increment = () => {
    this.setState({ count: this.state.count + 1 })
  }

  render() {
    console.log('render')
    return (
      <div>
        <header>
          <h1>Heading</h1>
        </header>
        count {this.state.count}
        <button onClick={this.increment}>increment</button>


        <div id="page">
          <h1>Heading Title</h1>
          <h2>Subheading Title</h2>
          <h2>Subheading Title</h2>
          <h1>Heading Title</h1>
          <h2>Subheading Title</h2>
          <h1>Heading Title</h1>
        </div>
      </div>
    )
  }
  shouldComponentUpdate() {
    return false
  }
  componentWillUpdate() {

  }
  componentDidUpdate() {
    console.log('componentDidUpdate');
  }

}

export default App

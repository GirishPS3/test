#! /bin/bash
echo "hello bash script" > file.txt

#! /bin/bash

#single line comment
echo "single line comment"

: '
multiple
line
comments'

echo "multiline"

cat << kreativ
multiline 
comments
can 
be
displayed
kreativ

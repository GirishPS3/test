#! /bin/bash

number=1
while [ $number -lt 6 ]
do
	echo $number
	number=$((number+1))
done


#echo $0 $1
#echo $1 $2
#args=("$@")

#echo ${args[1]} ${args[3]}

#echo $@

echo $#

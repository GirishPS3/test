#! /bin/bash

cat >> file.txt

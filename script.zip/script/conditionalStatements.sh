#! /bin/bash

count=11

#if [ $count -eq 10 ]
#if [ $count -ne 10 ]
: '
if (( $count < 10))
then
	echo "true condition"
else
	echo "false"
fi'

age =19
if [ "$age" -gt 18 ] && [ "$age" -lt 40 ]
then
	echo "age is correct
else
	echo " age is incorrect"
fi

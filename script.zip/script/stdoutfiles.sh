#! /bin/bash/

ls -al 1>file1.txt 2>file2.txt

